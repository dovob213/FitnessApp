package com.example.fitness

// 테스트용 파일 - 추후 삭제 예정
class person()
{
    var name : String? = "User"
    var age : Int? = 0
    var height : Int? = 0
}